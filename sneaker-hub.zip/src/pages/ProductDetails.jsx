import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import Loader from '../components/Loader';
import Button from '../components/Button';
import { Star, ShoppingBag, ArrowLeft, ShieldCheck, RefreshCw, Calendar, Truck } from 'lucide-react';
import { motion } from 'motion/react';

export default function ProductDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { products, loading, addToCart } = useShop();

  // 1. STATE FOR QUANTITY SELECTOR
  const [quantity, setQuantity] = useState(1);
  const [currentProduct, setCurrentProduct] = useState(null);

  // 2. RETRIEVE CORRESPONDING PRODUCT
  useEffect(() => {
    if (!loading && products.length > 0) {
      // Find the product by ID (match string/integer types correctly)
      const foundProduct = products.find((p) => p.id === parseInt(id, 10));
      if (foundProduct) {
        setCurrentProduct(foundProduct);
      }
    }
  }, [id, products, loading]);

  const handleIncrement = () => setQuantity((prev) => prev + 1);
  const handleDecrement = () => setQuantity((prev) => (prev > 1 ? prev - 1 : 1));

  const handleAddToCart = () => {
    if (currentProduct) {
      addToCart(currentProduct, quantity);
      
      // Visual notification/alert or alert banner helper
      alert(`Added ${quantity} x ${currentProduct.name} to your shopping cart successfully!`);
    }
  };

  if (loading) {
    return (
      <div className="py-24" id="details-loader-wrapper">
        <Loader />
      </div>
    );
  }

  // 3. ERROR FALLBACK (PRODUCT NOT FOUND)
  if (!currentProduct) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center space-y-4" id="details-error-state">
        <div className="w-16 h-16 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
          <ArrowLeft className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-black text-slate-800">Sneaker Not Found</h2>
        <p className="text-slate-500 text-sm max-w-sm mx-auto">
          The product ID you specified does not exist in our active catalog database.
        </p>
        <Link to="/products" className="inline-block mt-4">
          <Button variant="primary" className="h-11 px-6 font-bold rounded-xl text-xs">
            Back to Catalog
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12" id={`details-page-${currentProduct.id}`}>
      
      {/* NAVIGATION CRUMB & BACK ACTION */}
      <div id="details-back-crumb">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-slate-500 hover:text-black font-bold text-xs cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-orange-600" />
          Back to Previous Page
        </button>
      </div>

      {/* MAIN SPECIFICATIONS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-16 items-start" id="details-layout-grid">
        
        {/* PRODUCT IMAGE VIEWER (LEFT - 5 COLS) */}
        <div className="md:col-span-5 bg-white rounded-3xl p-8 border border-slate-200 shadow-sm shrink-0" id="details-img-viewer">
          <motion.img
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4 }}
            src={currentProduct.image}
            alt={currentProduct.name}
            className="w-full h-96 object-contain rounded-2xl mx-auto drop-shadow-md"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* SPECIFICATIONS CONTENT (RIGHT - 7 COLS) */}
        <div className="md:col-span-7 space-y-6" id="details-specifications">
          
          {/* Brand/Category Headers */}
          <div className="space-y-2">
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-black text-white rounded-xl text-xs font-black uppercase tracking-wider">
                {currentProduct.brand}
              </span>
              <span className="px-3 py-1 bg-orange-50 text-orange-700 rounded-xl text-xs font-black uppercase tracking-wider">
                {currentProduct.category}
              </span>
            </div>
            
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight mt-2">
              {currentProduct.name}
            </h1>
          </div>

          {/* Ratings Panel */}
          <div className="flex items-center gap-4 py-2 border-y border-slate-100" id="details-rating-panel">
            <div className="flex items-center gap-1.5 text-amber-500">
              <Star className="w-5 h-5 fill-current" />
              <span className="font-extrabold text-slate-900 text-md">{currentProduct.rating}</span>
            </div>
            <div className="text-slate-400 text-xs font-semibold uppercase tracking-wider border-l border-slate-200 pl-4">
              {currentProduct.reviews} verified reviews
            </div>
          </div>

          {/* PRICING */}
          <div className="space-y-1">
            <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Retail Price</p>
            <p className="text-3xl font-black text-slate-950">${currentProduct.price}</p>
          </div>

          {/* DESCRIPTION */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-800 text-sm">Product Description</h3>
            <p className="text-slate-600 text-sm leading-relaxed font-normal">
              {currentProduct.description}
            </p>
          </div>

          {/* QUANTITY & ADD TO CART CONTROLLER */}
          <div className="pt-6 border-t border-slate-200 space-y-4">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              
              {/* Quantity Selector UI */}
              <div className="flex items-center justify-between border border-slate-200 rounded-2xl bg-white p-2.5 h-12 w-full sm:w-36 shadow-sm">
                <button
                  onClick={handleDecrement}
                  className="p-1 hover:bg-slate-200 rounded-lg text-slate-600 cursor-pointer"
                  aria-label="Decrease quantity"
                >
                  <ArrowLeft className="w-4 h-4 shrink-0" />
                </button>
                <span className="font-black text-slate-900 text-sm select-none">
                  {quantity}
                </span>
                <button
                  onClick={handleIncrement}
                  className="p-1 hover:bg-slate-200 rounded-lg text-slate-600 cursor-pointer"
                  aria-label="Increase quantity"
                >
                  <ArrowLeft className="w-4 h-4 rotate-180 shrink-0" />
                </button>
              </div>

              {/* Add Button */}
              <Button
                onClick={handleAddToCart}
                variant="secondary"
                className="h-12 w-full sm:w-auto px-8 font-bold text-sm rounded-2xl flex items-center justify-center gap-2"
                id="btn-add-detail"
              >
                <ShoppingBag className="w-5 h-5" />
                Add to Cart Subtotal (${currentProduct.price * quantity})
              </Button>

            </div>
          </div>

          {/* TRUST BADGES / QUALITY SIGNALS */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 border-t border-slate-200 text-xs" id="details-trust-signals">
            <div className="flex gap-2.5 items-center text-slate-600">
              <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
              <span className="font-semibold">Genuine & Certified Original</span>
            </div>
            <div className="flex gap-2.5 items-center text-slate-600">
              <RefreshCw className="w-4 h-4 text-orange-500 shrink-0" />
              <span className="font-semibold">30-Day Exchange Warranty</span>
            </div>
            <div className="flex gap-2.5 items-center text-slate-600">
              <Truck className="w-5 h-5 text-orange-500 shrink-0" />
              <span className="font-semibold">Priority Delivery Eligible</span>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
