import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, HelpCircle, ShieldCheck } from 'lucide-react';
import Button from '../components/Button';

export default function Contact() {
  // 1. STATE FOR CONTACT FORM INPUTS
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const [loadingForm, setLoadingForm] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // 2. FORM SUBMISSION EVENT
  const handleSubmit = (e) => {
    e.preventDefault();
    setLoadingForm(true);

    // Simulate sending progress with a short setTimeout
    setTimeout(() => {
      setLoadingForm(false);
      alert(
        `Thank you for contacting Sneaker Hub, ${formData.name}! Your message about "${formData.subject}" was sent successfully. Our team will reach back in 24 hours.`
      );
      // Reset the inputs
      setFormData({
        name: '',
        email: '',
        subject: '',
        message: ''
      });
    }, 1000);
  };

  const contactDetails = [
    {
      icon: MapPin,
      title: 'Headquarters Storefront',
      detail: '123 Sneaker Boulevard, Street Fashion District, New York, NY 10001'
    },
    {
      icon: Phone,
      title: 'Telephone Support',
      detail: '+1 (555) SNEAKER (Mon - Fri, 9am - 6pm EST)'
    },
    {
      icon: Mail,
      title: 'Email Correspondence',
      detail: 'support@sneakerhub.com (Average reply within 4 hours)'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 pb-20 space-y-12" id="contact-page-root">
      
      {/* PAGE HEADER */}
      <section className="text-center space-y-3" id="contact-header">
        <span className="text-xs font-black uppercase tracking-widest px-3.5 py-1.5 bg-orange-500 text-black rounded-full font-bold">
          Get Support
        </span>
        <h1 className="text-4xl font-black text-slate-900 tracking-tight uppercase">
          HOW CAN WE HELP YOU?
        </h1>
        <p className="text-slate-500 text-sm max-w-lg mx-auto font-medium">
          Whether you need authentication details, order updates, or size exchanges, our dedicated support team is here to assist.
        </p>
      </section>

      {/* TWO COLUMN GRID: INFO vs FORM */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start" id="contact-main-grid">
        
        {/* LEFT COLUMN: CONTACT CARDS & FAQ PREVIEW (SPAN 5) */}
        <div className="lg:col-span-5 space-y-8" id="contact-info-panel">
          
          <div className="space-y-4">
            <h3 className="text-lg font-extrabold text-slate-900 tracking-tight">Direct Connections</h3>
            <p className="text-slate-500 text-xs">Reach out using any of our verified communication rails:</p>
          </div>

          <div className="space-y-4" id="contacts-list">
            {contactDetails.map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.title} className="p-5 bg-white rounded-3xl border border-slate-200 shadow-sm flex gap-4 hover:scale-[1.01] transition-transform">
                  <div className="p-2.5 bg-orange-50 text-orange-600 rounded-xl shadow-sm h-10 w-10 flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-xs sm:text-sm">{item.title}</h4>
                    <p className="text-slate-600 text-xs mt-1.5 leading-relaxed font-medium">{item.detail}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick FAQ summary box */}
          <div className="p-5 bg-orange-50 border border-orange-100 rounded-3xl space-y-3">
            <div className="flex gap-2 items-center text-orange-800">
              <HelpCircle className="w-5 h-5" />
              <h4 className="font-extrabold text-xs sm:text-sm">Looking for fast answers?</h4>
            </div>
            <p className="text-orange-950 text-xs leading-relaxed font-medium">
              Before submitting a custom ticket, check our newsletter or reach out directly to support regarding tracking IDs. Shipping thresholds take 1-3 business days to activate online tracking.
            </p>
          </div>

        </div>

        {/* RIGHT COLUMN: CORRESPONDENCE FORM (SPAN 7) */}
        <section className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6" id="contact-form-panel">
          
          <div className="space-y-1">
            <h3 className="text-lg font-black text-slate-900 tracking-tight">Submit a Support Ticket</h3>
            <p className="text-slate-400 text-xs">All fields are monitored securely inside our CRM framework.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4" id="ticket-submission-form">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* NAME FIELD */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Full Name</label>
                <input
                  type="text"
                  name="name"
                  required
                  placeholder="e.g. John Doe"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 text-xs font-medium"
                />
              </div>

              {/* EMAIL FIELD */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Email Address</label>
                <input
                  type="email"
                  name="email"
                  required
                  placeholder="e.g. john@example.com"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 text-xs font-medium"
                />
              </div>

            </div>

            {/* SUBJECT FIELD */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Subject Topic</label>
              <input
                type="text"
                name="subject"
                required
                placeholder="e.g. Inquiries regarding size exchange / refund"
                value={formData.subject}
                onChange={handleInputChange}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 text-xs font-medium"
              />
            </div>

            {/* MESSAGE TEXTAREA */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Your Message</label>
              <textarea
                name="message"
                required
                rows={5}
                placeholder="Write the details of your inquiry here..."
                value={formData.message}
                onChange={handleInputChange}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 text-xs font-medium resize-none"
              ></textarea>
            </div>

            {/* SUBMIT TRIGGER */}
            <div className="pt-2 flex flex-col sm:flex-row justify-between items-center gap-4 border-t border-slate-100">
              <div className="flex gap-1.5 items-center text-[10px] text-slate-400 font-medium">
                <ShieldCheck className="w-4 h-4 text-slate-500" />
                <span>Your privacy is protected under our offline cache rules.</span>
              </div>
              <Button
                type="submit"
                variant="secondary"
                disabled={loadingForm}
                className="w-full sm:w-auto h-11 px-6 rounded-xl text-xs font-bold flex items-center justify-center gap-2"
                id="btn-submit-ticket"
              >
                <Send className="w-4 h-4" />
                {loadingForm ? 'Submitting Ticket...' : 'Send Message'}
              </Button>
            </div>

          </form>

        </section>

      </div>

    </div>
  );
}
