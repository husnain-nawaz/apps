import React from 'react';
import { Award, Heart, Shield, Users } from 'lucide-react';
import { motion } from 'motion/react';

export default function About() {
  const values = [
    {
      icon: Shield,
      title: 'Guaranteed Authenticity',
      desc: 'Every single sneaker on our shelves is verified. We work directly with brands like Nike and Adidas to ensure 100% original quality, including box and tags.'
    },
    {
      icon: Award,
      title: 'Curated Excellence',
      desc: 'We do not sell everything. We select the finest colorways, limited-edition releases, and optimal performance sneakers to keep you ahead of the trend.'
    },
    {
      icon: Heart,
      title: 'Sneakerhead Passion',
      desc: 'Founded by athletes and sneaker collectors, we understand the thrill of a fresh pair. Our customer care is built around real community support.'
    }
  ];

  const team = [
    {
      name: 'Marcus Vance',
      role: 'Founder & Head Curator',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
      fav: 'Nike Air Max'
    },
    {
      name: 'Elena Rostova',
      role: 'Operations & Sourcing',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&auto=format&fit=crop&q=80',
      fav: 'Adidas Ultraboost'
    },
    {
      name: 'Tyler Durant',
      role: 'Logistics Lead',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&auto=format&fit=crop&q=80',
      fav: 'New Balance 990v6'
    }
  ];

  return (
    <div className="space-y-16 py-12 pb-20" id="about-page-root">
      
      {/* SECTION 1: HERO HEADER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4" id="about-hero">
        <span className="text-xs font-black uppercase tracking-widest px-3.5 py-1.5 bg-orange-500 text-black rounded-full font-bold">
          Our Heritage
        </span>
        <h1 className="text-4xl sm:text-5xl font-black text-slate-900 tracking-tight uppercase">
          SOURCING THE FUTURE OF FOOTWEAR
        </h1>
        <p className="text-slate-500 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed font-medium">
          At Sneaker Hub, we believe that shoes are more than just something you wear—they represent a lifestyle, an athletic standard, and a canvas for creative self-expression.
        </p>
      </section>

      {/* SECTION 2: BRAND STORY & GRID PHOTO */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="about-story">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          <div className="space-y-6">
            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Our Journey Since 2018</h2>
            <p className="text-slate-600 text-sm leading-relaxed">
              Sneaker Hub began in a small garage in New York with a simple mission: to make authentic, premium sneaker editions accessible to everyone without dealing with predatory resale fees and counterfeits.
            </p>
            <p className="text-slate-600 text-sm leading-relaxed">
              Today, we have grown into a nationwide community-backed platform, shipping thousands of verified athletic and lifestyle footwear units weekly. We combine state-of-the-art authentication testing with streamlined priority shipping logistics so you can step with confidence.
            </p>
            <div className="p-5 bg-orange-50 border border-orange-100 rounded-2xl">
              <p className="text-xs text-orange-950 font-bold italic leading-relaxed">
                "Our promise is simple: If we wouldn't wear them with pride on our own feet, we will never host them on our platform. Quality and authenticity are our guiding stars."
              </p>
              <p className="text-[10px] text-orange-600 font-black uppercase tracking-wider mt-2.5 text-right">— Marcus Vance, Founder</p>
            </div>
          </div>

          <div className="relative" id="about-img-box">
            <div className="absolute inset-0 bg-orange-500 rounded-3xl rotate-2 opacity-5 shadow-lg"></div>
            <img
              src="https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=800&auto=format&fit=crop&q=80"
              alt="Sneaker Sourcing Workshop"
              className="w-full h-80 object-cover rounded-3xl shadow-md border border-slate-200 transform -rotate-1 hover:rotate-0 transition-transform duration-300"
              referrerPolicy="no-referrer"
            />
          </div>

        </div>
      </section>

      {/* SECTION 3: CORE VALUES */}
      <section className="py-16" id="about-values">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center space-y-1">
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">Our Core Values</h2>
            <p className="text-slate-500 text-sm">The principles driving every release and transaction at Sneaker Hub.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((val) => {
              const Icon = val.icon;
              return (
                <div key={val.title} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4 hover:scale-[1.01] transition-transform">
                  <div className="p-3 bg-orange-50 text-orange-600 rounded-xl w-12 h-12 flex items-center justify-center">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="font-extrabold text-slate-900 text-md">{val.title}</h3>
                  <p className="text-slate-500 text-xs leading-relaxed font-medium">{val.desc}</p>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* SECTION 4: TEAM MEMBERS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12" id="about-team">
        <div className="text-center space-y-1">
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">Meet the Sourcing Team</h2>
          <p className="text-slate-500 text-sm">Passionate collectors dedicated to validating your next steps.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {team.map((member) => (
            <div key={member.name} className="text-center bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:scale-[1.01] transition-transform" id={`team-card-${member.name.toLowerCase().replace(/\s+/g, '-')}`}>
              <img
                src={member.image}
                alt={member.name}
                className="w-24 h-24 rounded-full object-cover mx-auto mb-4 border-2 border-orange-500/10 shadow-sm"
                referrerPolicy="no-referrer"
              />
              <h3 className="font-extrabold text-slate-900 text-sm">{member.name}</h3>
              <p className="text-xs text-orange-600 font-bold uppercase tracking-wider mt-0.5">{member.role}</p>
              <p className="text-slate-400 text-[10px] font-semibold uppercase mt-3">Favorite Fit: <span className="text-slate-700 font-bold">{member.fav}</span></p>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
