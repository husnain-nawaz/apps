import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import Hero from '../components/Hero';
import ProductCard from '../components/ProductCard';
import Loader from '../components/Loader';
import { ArrowRight, Star, Award, ShieldCheck, Truck } from 'lucide-react';
import { motion } from 'motion/react';
import Button from '../components/Button';

export default function Home() {
  const { products, loading } = useShop();
  const navigate = useNavigate();

  // Get the top 4 highly rated sneakers to showcase as featured products
  const featuredProducts = products
    .filter((p) => p.rating >= 4.6)
    .slice(0, 4);

  const popularBrands = [
    { name: 'Nike', bg: 'bg-white border border-slate-200 text-slate-900 hover:bg-black hover:text-white hover:border-black', slogan: 'Just Do It' },
    { name: 'Adidas', bg: 'bg-white border border-slate-200 text-slate-900 hover:bg-black hover:text-white hover:border-black', slogan: 'Impossible Is Nothing' },
    { name: 'Puma', bg: 'bg-white border border-slate-200 text-slate-900 hover:bg-black hover:text-white hover:border-black', slogan: 'Forever Faster' },
    { name: 'New Balance', bg: 'bg-white border border-slate-200 text-slate-900 hover:bg-black hover:text-white hover:border-black', slogan: 'Worn By Anyone' },
    { name: 'Converse', bg: 'bg-white border border-slate-200 text-slate-900 hover:bg-black hover:text-white hover:border-black', slogan: 'All Star' }
  ];

  return (
    <div className="space-y-16 pb-16" id="homepage-root">
      
      {/* 1. HERO BANNER */}
      <Hero />

      {/* 2. VALUE PROPOSITIONS / BENEFITS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="home-benefits">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex gap-4 items-start p-8 bg-white rounded-3xl border border-slate-200 shadow-sm hover:scale-[1.01] transition-transform">
            <div className="bg-orange-50 p-3 rounded-2xl text-orange-600">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-extrabold text-slate-900 text-md">Free Express Shipping</h4>
              <p className="text-slate-500 text-xs mt-1 font-medium">On all orders over $150. Fast delivery straight to your doorstep.</p>
            </div>
          </div>
          <div className="flex gap-4 items-start p-8 bg-white rounded-3xl border border-slate-200 shadow-sm hover:scale-[1.01] transition-transform">
            <div className="bg-orange-50 p-3 rounded-2xl text-orange-600">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-extrabold text-slate-900 text-md">100% Original Products</h4>
              <p className="text-slate-500 text-xs mt-1 font-medium">Directly sourced from official brands. We guarantee authentication.</p>
            </div>
          </div>
          <div className="flex gap-4 items-start p-8 bg-white rounded-3xl border border-slate-200 shadow-sm hover:scale-[1.01] transition-transform">
            <div className="bg-orange-50 p-3 rounded-2xl text-orange-600">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-extrabold text-slate-900 text-md">Easy 30-Day Returns</h4>
              <p className="text-slate-500 text-xs mt-1 font-medium">Not the right size? Return or exchange with absolutely no hassle.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. POPULAR BRANDS SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6" id="home-popular-brands">
        <div className="text-center md:text-left space-y-1">
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">Shop by Brand</h2>
          <p className="text-slate-500 text-sm">Explore premium sneaker catalogs from your favorite manufacturers.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {popularBrands.map((brand, idx) => (
            <motion.div
              key={brand.name}
              whileHover={{ y: -5 }}
              onClick={() => navigate(`/products?brand=${brand.name}`)}
              className={`p-6 rounded-2xl cursor-pointer text-center flex flex-col justify-between min-h-[140px] shadow-sm transition-all ${brand.bg}`}
              id={`brand-card-${brand.name.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <span className="text-xs font-black uppercase tracking-wider opacity-65">{brand.slogan}</span>
              <h3 className="text-xl font-extrabold tracking-tight mt-4">{brand.name}</h3>
              <div className="mt-2 text-xs font-bold flex items-center justify-center gap-1 opacity-80 hover:opacity-100">
                Explore <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* 4. FEATURED PRODUCTS GRID */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8" id="home-featured-products">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-center md:text-left space-y-1">
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">Trending Now</h2>
            <p className="text-slate-500 text-sm">Our most-loved, high-rating performance and street shoes.</p>
          </div>
          <Link to="/products">
            <Button variant="outline" className="text-xs font-bold rounded-xl h-10 px-4 flex items-center gap-1.5">
              View All Shoes <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>

        {loading ? (
          <Loader />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="featured-products-grid">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>

      {/* 5. PROMOTION BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="home-promo-banner">
        <div className="bg-black text-white rounded-3xl p-8 md:p-12 relative overflow-hidden shadow-lg flex flex-col md:flex-row justify-between items-center gap-8 border border-slate-800">
          {/* visual ring glow */}
          <div className="absolute right-[-10%] top-[-20%] w-96 h-96 rounded-full bg-orange-500/10 blur-3xl"></div>
          
          <div className="space-y-4 max-w-xl text-center md:text-left relative z-10">
            <span className="bg-orange-500 text-black text-[10px] font-black uppercase tracking-widest px-3.5 py-1.5 rounded-full">
              Exclusive Deal
            </span>
            <h3 className="text-3xl sm:text-4xl font-black tracking-tight uppercase">Get 15% Off Your First Order</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Join the Sneaker Hub family. Subscribe to our newsletter or create an account today to secure high-quality footwear discounts, limited edition alerts, and free priority shipping.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto shrink-0 relative z-10">
            <input
              type="email"
              placeholder="Enter your email"
              className="px-5 py-3 rounded-xl bg-white/10 text-white border border-white/10 placeholder-slate-500 focus:outline-none focus:border-orange-500 text-sm font-medium w-full sm:w-64"
            />
            <Button
              variant="secondary"
              onClick={() => alert('Thanks for joining our newsletter! Use coupon code SNEAKER15 at checkout.')}
              className="h-12 text-sm px-6 font-bold shrink-0 rounded-xl bg-orange-500 text-black hover:bg-white hover:text-black transition-colors"
            >
              Subscribe
            </Button>
          </div>
        </div>
      </section>

    </div>
  );
}
