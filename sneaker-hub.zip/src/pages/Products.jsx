import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import ProductCard from '../components/ProductCard';
import SearchBar from '../components/SearchBar';
import BrandFilter from '../components/BrandFilter';
import CategoryFilter from '../components/CategoryFilter';
import Loader from '../components/Loader';
import { SlidersHorizontal, ArrowUpDown, RotateCcw } from 'lucide-react';
import Button from '../components/Button';

export default function Products() {
  const { products, loading } = useShop();
  const [searchParams, setSearchParams] = useSearchParams();

  // 1. STATE FOR FILTERING & SORTING
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('featured'); // 'featured', 'price-low-high', 'price-high-low', 'rating'

  // 2. PARSE SEARCH PARAMS ON LOAD (Allows navigation filtering like Home -> Nike Products)
  useEffect(() => {
    const brandParam = searchParams.get('brand');
    const categoryParam = searchParams.get('category');

    if (brandParam) setSelectedBrand(brandParam);
    if (categoryParam) setSelectedCategory(categoryParam);
  }, [searchParams]);

  // 3. RESET ALL FILTERS
  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedBrand('All');
    setSelectedCategory('All');
    setSortBy('featured');
    setSearchParams({}); // Clear query string
  };

  // 4. FILTER AND SORT LOGIC
  const filteredAndSortedProducts = products
    .filter((product) => {
      // Filter by Search Query
      const matchesSearch =
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      // Filter by Brand
      const matchesBrand = selectedBrand === 'All' || product.brand === selectedBrand;
      
      // Filter by Category
      const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;

      return matchesSearch && matchesBrand && matchesCategory;
    })
    .sort((a, b) => {
      // Sort Logic
      if (sortBy === 'price-low-high') {
        return a.price - b.price;
      }
      if (sortBy === 'price-high-low') {
        return b.price - a.price;
      }
      if (sortBy === 'rating') {
        return b.rating - a.rating;
      }
      // 'featured' defaults to natural order / highest review counts
      return b.reviews - a.reviews;
    });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8" id="products-page-root">
      
      {/* PAGE HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-6" id="products-header">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Sneaker Inventory</h1>
          <p className="text-slate-500 text-sm mt-1">
            Showing {filteredAndSortedProducts.length} of {products.length} premium models
          </p>
        </div>
        
        {/* Reset / Clean Filters */}
        {(searchQuery || selectedBrand !== 'All' || selectedCategory !== 'All' || sortBy !== 'featured') && (
          <Button
            onClick={handleResetFilters}
            variant="outline"
            className="text-xs h-10 rounded-xl px-4 flex items-center gap-2 text-slate-500 hover:text-slate-800"
            id="btn-reset-all-filters"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Clear All Filters
          </Button>
        )}
      </div>

      {loading ? (
        <Loader />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8" id="products-main-layout">
          
          {/* SIDEBAR FILTERS (SPAN 1 COLUMN ON DESKTOP) */}
          <aside className="space-y-6 lg:border-r lg:border-slate-200 lg:pr-6" id="products-filter-sidebar">
            <div className="flex items-center gap-2 font-black text-slate-800 uppercase tracking-wider text-xs pb-4 border-b border-slate-200">
              <SlidersHorizontal className="w-4 h-4 text-orange-600" />
              Filter Catalog
            </div>

            {/* SEARCH */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Search Product</h4>
              <SearchBar
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onClear={() => setSearchQuery('')}
              />
            </div>

            {/* BRAND */}
            <BrandFilter
              selectedBrand={selectedBrand}
              onSelectBrand={(brand) => {
                setSelectedBrand(brand);
                setSearchParams(brand === 'All' ? {} : { brand });
              }}
            />

            {/* CATEGORY */}
            <CategoryFilter
              selectedCategory={selectedCategory}
              onSelectCategory={(cat) => {
                setSelectedCategory(cat);
                setSearchParams(cat === 'All' ? {} : { category: cat });
              }}
            />

            {/* SORTING SELECT */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Sort Products</h4>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 pointer-events-none">
                  <ArrowUpDown className="w-4 h-4" />
                </span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-white border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/20 text-xs font-bold text-slate-700 appearance-none cursor-pointer shadow-sm"
                  id="sort-select-dropdown"
                >
                  <option value="featured">Featured Picks</option>
                  <option value="price-low-high">Price: Low to High</option>
                  <option value="price-high-low">Price: High to Low</option>
                  <option value="rating">Top Customer Ratings</option>
                </select>
              </div>
            </div>
          </aside>

          {/* SNEAKERS GRID (SPAN 3 COLUMNS ON DESKTOP) */}
          <section className="lg:col-span-3 space-y-6" id="products-catalog-grid-wrapper">
            {filteredAndSortedProducts.length === 0 ? (
              <div className="text-center py-20 bg-slate-50 rounded-3xl border border-dashed border-slate-200" id="empty-results-state">
                <SlidersHorizontal className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <h3 className="font-extrabold text-slate-800 text-lg">No Sneakers Found</h3>
                <p className="text-slate-500 text-sm mt-1 max-w-sm mx-auto">
                  We couldn't find any products matching your search criteria. Try modifying your filters or clear them to start over.
                </p>
                <Button onClick={handleResetFilters} variant="secondary" className="mt-5 text-xs font-bold rounded-xl h-10 px-6 mx-auto">
                  Reset Filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6" id="products-grid-list">
                {filteredAndSortedProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </section>

        </div>
      )}

    </div>
  );
}
