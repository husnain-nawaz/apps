import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import Sidebar from '../components/Sidebar';
import ProductTable from '../components/ProductTable';
import Button from '../components/Button';
import { Package, FolderHeart, ShoppingCart, PlusCircle, X, CheckCircle, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function AdminDashboard() {
  const { products, cartCount, addProduct, updateProduct, deleteProduct } = useShop();

  // 1. TABS MANAGEMENT: 'dashboard' | 'products'
  const [activeTab, setActiveTab] = useState('dashboard');

  // 2. MODAL FORMS MANAGEMENT
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null); // null if adding new product, contains product if editing

  // Form input states
  const [formName, setFormName] = useState('');
  const [formBrand, setFormBrand] = useState('Nike');
  const [formCategory, setFormCategory] = useState('Running');
  const [formPrice, setFormPrice] = useState('');
  const [formImage, setFormImage] = useState('');
  const [formDescription, setFormDescription] = useState('');

  // Compute unique categories dynamically
  const uniqueCategories = Array.from(new Set(products.map((p) => p.category)));

  // 3. OPEN ADD FORM
  const handleOpenAddForm = () => {
    setEditingProduct(null);
    setFormName('');
    setFormBrand('Nike');
    setFormCategory('Running');
    setFormPrice('');
    
    // Default to a gorgeous placeholder shoe image to make it easy for beginners
    setFormImage('https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop&q=60');
    setFormDescription('This is a high-performance sneaker designed for comfort, agility, and elite street wear aesthetics.');
    setIsModalOpen(true);
  };

  // 4. OPEN EDIT FORM
  const handleOpenEditForm = (product) => {
    setEditingProduct(product);
    setFormName(product.name);
    setFormBrand(product.brand);
    setFormCategory(product.category);
    setFormPrice(product.price);
    setFormImage(product.image);
    setFormDescription(product.description);
    setIsModalOpen(true);
  };

  // 5. SUBMIT FORM HANDLER (ADD OR UPDATE)
  const handleFormSubmit = (e) => {
    e.preventDefault();

    if (!formName || !formPrice || !formImage) {
      alert('Please fill out all required fields.');
      return;
    }

    const itemData = {
      name: formName,
      brand: formBrand,
      category: formCategory,
      price: parseFloat(formPrice),
      image: formImage,
      description: formDescription
    };

    if (editingProduct) {
      // Execute simulated UPDATE
      updateProduct(editingProduct.id, itemData);
      alert(`Successfully updated: "${formName}"`);
    } else {
      // Execute simulated CREATE
      addProduct(itemData);
      alert(`Successfully added new sneaker: "${formName}"`);
    }

    setIsModalOpen(false);
  };

  return (
    <div className="flex flex-col md:flex-row min-h-[calc(100vh-4rem)]" id="admin-panel-root">
      
      {/* SIDEBAR NAVIGATION PANEL */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* RIGHT SIDE MAIN DASHBOARD CONTENT AREA */}
      <main className="flex-grow p-6 md:p-10 space-y-8 bg-slate-50/50" id="admin-main-panel">
        
        {/* TAB 1: OVERVIEW PANEL VIEW */}
        {activeTab === 'dashboard' && (
          <div className="space-y-8" id="overview-dashboard-tab">
            <div id="overview-header">
              <h1 className="text-2xl font-black text-slate-900 tracking-tight">Admin System Overview</h1>
              <p className="text-slate-500 text-xs mt-1">Real-time indicators tracking store inventory statistics</p>
            </div>

            {/* DASHBOARD CARDS GRID */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6" id="dashboard-metric-cards">
              
              {/* CARD 1: TOTAL PRODUCTS */}
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between hover:scale-[1.01] transition-transform">
                <div className="space-y-1">
                  <p className="text-slate-400 text-xs font-black uppercase tracking-wider">Total Shoe Models</p>
                  <p className="text-3xl font-black text-slate-900">{products.length}</p>
                </div>
                <div className="p-3 bg-orange-50 text-orange-600 rounded-2xl">
                  <Package className="w-6 h-6" />
                </div>
              </div>

              {/* CARD 2: TOTAL UNIQUE CATEGORIES */}
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between hover:scale-[1.01] transition-transform">
                <div className="space-y-1">
                  <p className="text-slate-400 text-xs font-black uppercase tracking-wider">Unique Categories</p>
                  <p className="text-3xl font-black text-slate-900">{uniqueCategories.length}</p>
                </div>
                <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
                  <FolderHeart className="w-6 h-6" />
                </div>
              </div>

              {/* CARD 3: USER CART ITEMS COUNT */}
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between hover:scale-[1.01] transition-transform">
                <div className="space-y-1">
                  <p className="text-slate-400 text-xs font-black uppercase tracking-wider">Active Cart Items</p>
                  <p className="text-3xl font-black text-slate-900">{cartCount}</p>
                </div>
                <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl">
                  <ShoppingCart className="w-6 h-6" />
                </div>
              </div>

            </div>

            {/* WELCOME / HELP GRAPHICS */}
            <div className="bg-black text-white p-6 sm:p-8 rounded-3xl relative overflow-hidden shadow-sm space-y-4 border border-slate-950" id="dashboard-quickstart-banner">
              <div className="absolute right-[-5%] top-[-20%] w-64 h-64 rounded-full bg-orange-500/10 blur-2xl"></div>
              
              <div className="space-y-1 max-w-xl">
                <h3 className="text-lg sm:text-xl font-bold uppercase tracking-tight">Welcome back, Shop Operator!</h3>
                <p className="text-slate-300 text-xs leading-relaxed font-medium">
                  This simulated Admin Panel gives you complete control over the Sneaker Hub storefront. You can instantly create, update, and delete shoes in real-time. All adjustments are safely held in local storage to prevent session loss.
                </p>
              </div>
              <div className="flex gap-4 pt-2">
                <Button variant="secondary" onClick={() => setActiveTab('products')} className="bg-orange-600 text-white hover:bg-orange-500 text-xs font-black px-5 h-9 rounded-xl uppercase">
                  Go Manage Products
                </Button>
              </div>
            </div>

            {/* RECENTLY REGISTERED INVENTORY */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4" id="recent-inventory-list">
              <h3 className="text-sm font-extrabold text-slate-900 tracking-tight border-b border-slate-200 pb-2">
                Active Catalog Sneak-peek (First 3)
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {products.slice(0, 3).map((prod) => (
                  <div key={prod.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50 flex items-center gap-3">
                    <img src={prod.image} alt={prod.name} className="w-10 h-10 object-contain" referrerPolicy="no-referrer" />
                    <div className="overflow-hidden">
                      <p className="font-bold text-slate-800 text-xs truncate">{prod.name}</p>
                      <p className="text-[10px] text-orange-600 font-extrabold mt-0.5">${prod.price}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: MANAGE PRODUCTS INVENTORY LIST */}
        {activeTab === 'products' && (
          <div className="space-y-8" id="manage-products-tab">
            <div id="table-head-summary">
              <h1 className="text-2xl font-black text-slate-900 tracking-tight">Manage Inventory</h1>
              <p className="text-slate-500 text-xs mt-1">Create, update, or remove sneakers inside your catalog database</p>
            </div>

            <ProductTable
              products={products}
              onEditProduct={handleOpenEditForm}
              onDeleteProduct={deleteProduct}
              onAddNewTrigger={handleOpenAddForm}
            />
          </div>
        )}

      </main>

      {/* 6. CRUD MODAL OVERLAY (ADD/EDIT FORM) */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm" id="crud-modal-backdrop">
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-white rounded-3xl border border-slate-100 shadow-2xl w-full max-w-lg overflow-hidden"
              id="crud-modal-container"
            >
              
              {/* Modal Header */}
              <div className="px-6 py-4 bg-black text-white flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <PlusCircle className="w-5 h-5 text-orange-500" />
                  <h3 className="font-extrabold text-sm sm:text-md uppercase">
                    {editingProduct ? `Edit Sneaker: #${editingProduct.id}` : 'Register New Sneaker'}
                  </h3>
                </div>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 hover:bg-slate-900 rounded-lg text-slate-400 hover:text-white transition-colors cursor-pointer"
                  aria-label="Close form"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body Form */}
              <form onSubmit={handleFormSubmit} className="p-6 space-y-4 text-xs font-medium text-slate-700 bg-white" id="crud-modal-form">
                
                {/* NAME */}
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Sneaker Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Nike Air Max Vapor"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/15 focus:border-orange-500 font-bold text-slate-800"
                  />
                </div>

                {/* BRAND & CATEGORY (ROW) */}
                <div className="grid grid-cols-2 gap-4">
                  
                  {/* BRAND SELECT */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Brand Sourcing *</label>
                    <select
                      value={formBrand}
                      onChange={(e) => setFormBrand(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/15 text-slate-800 font-bold cursor-pointer bg-white"
                    >
                      <option value="Nike">Nike</option>
                      <option value="Adidas">Adidas</option>
                      <option value="Puma">Puma</option>
                      <option value="New Balance">New Balance</option>
                      <option value="Converse">Converse</option>
                    </select>
                  </div>

                  {/* CATEGORY SELECT */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Category Type *</label>
                    <select
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/15 text-slate-800 font-bold cursor-pointer bg-white"
                    >
                      <option value="Running">Running</option>
                      <option value="Casual">Casual</option>
                      <option value="Sports">Sports</option>
                    </select>
                  </div>

                </div>

                {/* PRICE & IMAGE (ROW) */}
                <div className="grid grid-cols-2 gap-4">
                  
                  {/* PRICE FIELD */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Price (USD) *</label>
                    <input
                      type="number"
                      required
                      min={1}
                      placeholder="e.g. 120"
                      value={formPrice}
                      onChange={(e) => setFormPrice(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/15 focus:border-orange-500 font-bold text-slate-800"
                    />
                  </div>

                  {/* IMAGE URL FIELD */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Image URL *</label>
                    <input
                      type="url"
                      required
                      placeholder="https://images.unsplash.com/..."
                      value={formImage}
                      onChange={(e) => setFormImage(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/15 focus:border-orange-500 text-slate-800 font-normal truncate"
                    />
                  </div>

                </div>

                {/* DESCRIPTION */}
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Detailed Specifications</label>
                  <textarea
                    rows={4}
                    placeholder="Enter style guides, cushioning specs, or colorway descriptions..."
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/15 focus:border-orange-500 text-slate-850 font-normal resize-none"
                  ></textarea>
                </div>

                {/* TRIGGER ACTION ROW */}
                <div className="pt-4 border-t border-slate-200 flex gap-3 justify-end">
                  <Button
                    onClick={() => setIsModalOpen(false)}
                    variant="outline"
                    className="text-xs h-10 px-4 rounded-xl font-bold"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    variant="secondary"
                    className="text-xs h-10 px-6 rounded-xl font-bold flex items-center gap-1.5"
                    id="btn-submit-inventory-form"
                  >
                    <CheckCircle className="w-4 h-4" />
                    {editingProduct ? 'Save Sneaker Specifications' : 'Submit Sneaker registration'}
                  </Button>
                </div>

              </form>

            </motion.div>

          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
