import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import CartItem from '../components/CartItem';
import Button from '../components/Button';
import { ShoppingBag, ArrowLeft, Trash2, Tag, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Cart() {
  const { cart, cartTotal, clearCart } = useShop();
  const navigate = useNavigate();

  // 1. STATE FOR PROMO CODE & DISCOUNT
  const [promoCode, setPromoCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState(0); // 0.15 for 15%
  const [promoError, setPromoError] = useState('');
  const [promoSuccess, setPromoSuccess] = useState('');

  // 2. SHIPPING & TAX CALCULATION
  const shippingThreshold = 150;
  const shippingFee = cartTotal >= shippingThreshold || cartTotal === 0 ? 0 : 15;
  const estimatedTax = Math.round(cartTotal * 0.08 * 100) / 100; // 8% sales tax

  const discountAmount = Math.round(cartTotal * appliedDiscount * 100) / 100;
  const grandTotal = Math.max(0, Math.round((cartTotal - discountAmount + shippingFee + estimatedTax) * 100) / 100);

  // 3. APPLY PROMO CODE FUNCTION
  const handleApplyPromo = (e) => {
    e.preventDefault();
    if (promoCode.trim().toUpperCase() === 'SNEAKER15') {
      setAppliedDiscount(0.15);
      setPromoSuccess('Promo coupon SNEAKER15 (15% OFF) applied successfully!');
      setPromoError('');
    } else {
      setPromoError('Invalid promo coupon code. Try entering: SNEAKER15');
      setPromoSuccess('');
    }
  };

  // 4. SIMULATED CHECKOUT FUNCTION
  const handleCheckout = () => {
    // Confirm order placement
    const confirmOrder = window.confirm(
      `Proceed to place your order for a total of $${grandTotal}?`
    );

    if (confirmOrder) {
      alert('Thank you for shopping with Sneaker Hub! Your order has been placed successfully. A receipt was sent to your registered email.');
      clearCart(); // Empty the cart from state and LocalStorage
      navigate('/'); // Go back to Home
    }
  };

  // 5. EMPTY CART VIEW
  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center space-y-6" id="empty-cart-view">
        <div className="w-20 h-20 bg-white border border-slate-200 text-slate-400 rounded-full flex items-center justify-center mx-auto shadow-sm">
          <ShoppingBag className="w-10 h-10 text-orange-600" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-black text-slate-800">Your Cart is Empty</h2>
          <p className="text-slate-500 text-sm max-w-sm mx-auto font-medium">
            You haven't added any shoes to your shopping cart yet. Start browsing our catalog of premium sneakers to find your perfect fit!
          </p>
        </div>
        <Link to="/products" className="inline-block">
          <Button variant="secondary" className="h-11 px-8 font-bold rounded-xl text-xs flex items-center gap-2">
            Browse Catalog Now <ArrowLeft className="w-4 h-4 rotate-180" />
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8" id="cart-page-root">
      
      {/* PAGE HEADER */}
      <div className="flex justify-between items-center border-b border-slate-200 pb-6" id="cart-header">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Shopping Cart</h1>
          <p className="text-slate-500 text-sm mt-1">Review your selected items before checkout</p>
        </div>
        <button
          onClick={() => {
            if (window.confirm('Are you sure you want to empty your shopping cart?')) {
              clearCart();
            }
          }}
          className="flex items-center gap-1 text-slate-400 hover:text-rose-600 text-xs font-bold py-2 px-3 rounded-xl hover:bg-rose-50 transition-all cursor-pointer border border-transparent hover:border-rose-100"
          id="btn-clear-cart"
        >
          <Trash2 className="w-4 h-4" />
          Empty Cart
        </button>
      </div>

      {/* CART LAYOUT GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start" id="cart-grid-layout">
        
        {/* LEFT COLUMN: SELECTED ITEMS (SPAN 8) */}
        <div className="lg:col-span-8 space-y-4" id="cart-items-column">
          <div className="flex items-center justify-between font-extrabold text-xs text-slate-400 uppercase tracking-wider px-2">
            <span>Sneaker Selection</span>
            <span>Subtotal</span>
          </div>
          
          <div className="space-y-3">
            <AnimatePresence>
              {cart.map((item) => (
                <CartItem key={item.id} item={item} />
              ))}
            </AnimatePresence>
          </div>

          {/* Quick back navigation */}
          <Link to="/products" className="inline-flex items-center gap-2 text-orange-600 font-bold text-xs mt-4 pl-2 hover:underline">
            <ArrowLeft className="w-4 h-4" />
            Continue shopping more sneakers
          </Link>
        </div>

        {/* RIGHT COLUMN: ORDER SUMMARY SIDEBAR (SPAN 4) */}
        <aside className="lg:col-span-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-6 shrink-0" id="cart-summary-sidebar">
          <h3 className="text-md font-extrabold text-slate-900 tracking-tight border-b border-slate-200 pb-3">
            Order Summary
          </h3>

          {/* MATH RECAP BREAKDOWN */}
          <div className="space-y-3.5 text-xs text-slate-600 font-medium" id="summary-breakdown">
            <div className="flex justify-between">
              <span>Subtotal price</span>
              <span className="font-extrabold text-slate-900 text-sm">${cartTotal}</span>
            </div>
            
            {/* Promo Discount line if applied */}
            {appliedDiscount > 0 && (
              <div className="flex justify-between text-emerald-600 font-semibold">
                <span className="flex items-center gap-1">
                  <Tag className="w-3 h-3" /> Discount (15%)
                </span>
                <span>-${discountAmount}</span>
              </div>
            )}

            <div className="flex justify-between">
              <span>Estimated Sales Tax (8%)</span>
              <span className="font-extrabold text-slate-900 text-sm">${estimatedTax}</span>
            </div>
            
            <div className="flex justify-between">
              <span className="flex flex-col">
                <span>Shipping Fees</span>
                {shippingFee === 0 && <span className="text-[10px] text-emerald-600 font-bold">Free Shipping active</span>}
              </span>
              <span className="font-extrabold text-slate-900 text-sm">
                {shippingFee === 0 ? 'FREE' : `$${shippingFee}`}
              </span>
            </div>

            {shippingFee > 0 && (
              <p className="text-[10px] text-slate-400 font-normal italic">
                Add <span className="font-bold text-slate-500">${shippingThreshold - cartTotal}</span> more to unlock Free Express Shipping.
              </p>
            )}

            {/* GRAND TOTAL */}
            <div className="flex justify-between items-center pt-4 border-t border-slate-200 font-extrabold text-slate-900">
              <span className="text-sm font-black">Grand Total</span>
              <span className="text-xl font-black text-orange-600">${grandTotal}</span>
            </div>
          </div>

          {/* EDUCATIONAL PROMO FORM */}
          <form onSubmit={handleApplyPromo} className="space-y-2 border-t border-slate-200 pt-4" id="promo-code-form">
            <label className="text-[10px] text-slate-400 font-black uppercase tracking-wider block">
              Do you have a coupon code?
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="e.g. SNEAKER15"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value)}
                disabled={appliedDiscount > 0}
                className="flex-grow px-3 py-2 text-xs rounded-xl border border-slate-200 uppercase font-bold focus:outline-none focus:border-orange-500 disabled:opacity-50"
              />
              <Button
                type="submit"
                variant="outline"
                disabled={appliedDiscount > 0 || !promoCode}
                className="text-xs h-9 px-3 rounded-xl font-extrabold"
              >
                Apply
              </Button>
            </div>
            
            {/* Promo application status indicators */}
            {promoError && <p className="text-[10px] text-rose-500 font-semibold">{promoError}</p>}
            {promoSuccess && <p className="text-[10px] text-emerald-600 font-semibold">{promoSuccess}</p>}
            
            {appliedDiscount === 0 && (
              <p className="text-[10px] text-slate-400 font-medium">
                Tip: Enter <span className="font-bold text-orange-500">SNEAKER15</span> to get a 15% discount on checkout.
              </p>
            )}
          </form>

          {/* CHECKOUT ACTION BUTTON */}
          <div className="pt-4 border-t border-slate-200 space-y-3" id="summary-checkout-actions">
            <Button
              onClick={handleCheckout}
              variant="secondary"
              className="w-full h-12 rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-sm bg-orange-600 text-white hover:bg-orange-500"
              id="btn-checkout"
            >
              Confirm Checkout & Place Order
            </Button>
            
            <div className="flex gap-2 items-start text-[10px] text-slate-400 p-2.5 bg-slate-50 border border-slate-200 rounded-xl">
              <ShieldAlert className="w-4 h-4 text-slate-500 shrink-0" />
              <span>We use modern SSL encryption. Your shopping and credential data are strictly secure and kept offline in local storage.</span>
            </div>
          </div>

        </aside>

      </div>

    </div>
  );
}
