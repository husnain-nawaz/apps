import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

// Layout wrapper for general pages, ensuring unified Navbar and Footer display
export default function MainLayout({ children }) {
  return (
    <div className="min-h-screen flex flex-col bg-[#f0f2f5]" id="main-layout-root">
      {/* Sticky Header */}
      <Navbar />
      
      {/* Dynamic Content Area */}
      <main className="flex-grow" id="main-content-flow">
        {children}
      </main>
      
      {/* Global Footer */}
      <Footer />
    </div>
  );
}
