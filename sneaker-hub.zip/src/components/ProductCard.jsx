import React from 'react';
import { Link } from 'react-router-dom';
import { Star, ShoppingBag, Eye } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { motion } from 'motion/react';
import Button from './Button';

export default function ProductCard({ product }) {
  const { addToCart } = useShop();

  const handleAddToCart = (e) => {
    // Prevent clicking the button from triggering the parent Link navigation to details
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
  };

  return (
    <motion.div
      whileHover={{ y: -6 }}
      className="bg-white rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-all overflow-hidden flex flex-col h-full group"
      id={`product-card-${product.id}`}
    >
      {/* CARD TOP IMAGE LINK */}
      <Link to={`/product/${product.id}`} className="block relative bg-slate-50/50 overflow-hidden shrink-0 border-b border-slate-100">
        {/* Brand badge overlay */}
        <span className="absolute top-3 left-3 z-10 px-2.5 py-1 rounded-lg text-xs font-extrabold bg-black text-white shadow-sm">
          {product.brand}
        </span>
        
        {/* Hover overlay with detail text */}
        <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity z-10 flex items-center justify-center">
          <span className="bg-black text-white p-2.5 rounded-full shadow-lg transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
            <Eye className="w-5 h-5 text-white" />
          </span>
        </div>

        <img
          src={product.image}
          alt={product.name}
          className="w-full h-56 object-contain p-4 group-hover:scale-105 transition-transform duration-300"
          referrerPolicy="no-referrer"
        />
      </Link>

      {/* CARD CONTENT */}
      <div className="p-5 flex flex-col flex-grow justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex justify-between items-center text-xs text-slate-500 font-medium">
            <span className="bg-slate-100 text-slate-800 font-bold px-2.5 py-0.5 rounded-lg">{product.category}</span>
            
            {/* RATING */}
            <div className="flex items-center gap-1 text-orange-500">
              <Star className="w-3.5 h-3.5 fill-current" />
              <span className="font-extrabold">{product.rating}</span>
            </div>
          </div>

          <Link to={`/product/${product.id}`} className="block">
            <h3 className="font-extrabold text-slate-900 text-md group-hover:text-orange-600 transition-colors line-clamp-1">
              {product.name}
            </h3>
          </Link>
        </div>

        {/* PRICING & BUTTON */}
        <div className="flex items-center justify-between mt-auto pt-2 border-t border-slate-100">
          <div>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Price</p>
            <p className="text-lg font-black text-slate-900">${product.price}</p>
          </div>

          <Button
            onClick={handleAddToCart}
            variant="secondary"
            className="h-10 px-3.5 rounded-xl text-xs flex items-center gap-1.5 font-bold uppercase tracking-wider bg-black text-white hover:bg-orange-600 hover:text-white"
            id={`add-to-cart-btn-${product.id}`}
          >
            <ShoppingBag className="w-4 h-4" />
            Add
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
