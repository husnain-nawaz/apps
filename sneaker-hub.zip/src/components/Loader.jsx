import React from 'react';

// Loader component to display during API fetch requests or slow loadings
export default function Loader() {
  return (
    <div className="flex flex-col items-center justify-center py-16" id="loader-container">
      <div className="relative" id="loader-spinner">
        {/* Outer glowing ring */}
        <div className="w-16 h-16 rounded-full border-4 border-slate-100 border-t-indigo-600 animate-spin"></div>
        {/* Inner static/slow circle */}
        <div className="absolute top-2 left-2 w-12 h-12 rounded-full border-4 border-slate-200 border-b-slate-400 opacity-30"></div>
      </div>
      <p className="mt-4 text-slate-500 font-medium animate-pulse text-sm">
        Loading sneakers from Sneaker Hub API...
      </p>
    </div>
  );
}
