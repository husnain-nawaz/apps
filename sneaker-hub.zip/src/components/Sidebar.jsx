import React from 'react';
import { LayoutDashboard, List, Shield, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

// Sidebar component for Admin Panel
// Props:
// - activeTab: 'dashboard' | 'products'
// - setActiveTab: callback function to update parent state
export default function Sidebar({ activeTab, setActiveTab }) {
  const tabs = [
    { id: 'dashboard', label: 'Overview Panel', icon: LayoutDashboard },
    { id: 'products', label: 'Manage Products', icon: List }
  ];

  return (
    <aside className="w-full md:w-64 bg-black text-slate-300 flex flex-col md:min-h-[calc(100vh-4rem)] border-r border-slate-900 shrink-0" id="admin-sidebar">
      
      {/* Sidebar Header / Profile */}
      <div className="p-6 border-b border-slate-900" id="sidebar-profile">
        <div className="flex items-center gap-3">
          <div className="bg-orange-600 p-2.5 rounded-xl text-white">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-extrabold text-white text-sm">Staff Admin</h4>
            <p className="text-xs text-orange-500 font-semibold uppercase tracking-wider">Active Session</p>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <nav className="flex-grow p-4 space-y-2" id="sidebar-nav">
        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider px-3 mb-2">Management</p>
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                isActive
                  ? 'bg-orange-600 text-white shadow-sm font-black'
                  : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
              }`}
              id={`sidebar-tab-${tab.id}`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {tab.label}
            </button>
          );
        })}
      </nav>

      {/* Quick back link */}
      <div className="p-4 border-t border-slate-900" id="sidebar-footer">
        <Link
          to="/products"
          className="flex items-center justify-center gap-2 w-full px-4 py-2.5 rounded-xl border border-slate-900 text-xs font-bold hover:bg-slate-900 hover:text-white transition-all text-slate-400"
          id="sidebar-back-link"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Back to Storefront
        </Link>
      </div>

    </aside>
  );
}
