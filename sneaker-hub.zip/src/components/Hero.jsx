import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import Button from './Button';

export default function Hero() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8" id="home-hero">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* HERO BENTO CARD (Black theme, spans 7 cols) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="lg:col-span-7 bg-black rounded-3xl p-8 sm:p-12 relative overflow-hidden flex flex-col justify-between min-h-[460px] shadow-lg text-white"
          id="hero-bento-left"
        >
          {/* Big transparent background text */}
          <div className="absolute top-10 right-10 opacity-10 text-[100px] sm:text-[160px] font-black italic select-none leading-none text-white pointer-events-none">
            MAX
          </div>
          
          {/* Top Pill Accent */}
          <div className="relative z-10 self-start">
            <span className="bg-orange-500 text-black px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest mb-6 inline-flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Summer '26 Drop
            </span>
          </div>

          {/* Main heading and description */}
          <div className="relative z-10 mt-auto space-y-4">
            <h1 className="text-4xl sm:text-6xl font-black text-white leading-[0.95]" id="hero-title">
              STEP INTO STYLE,<br />
              ELEVATE YOUR GAME
            </h1>
            <p className="text-slate-400 text-sm max-w-md leading-relaxed" id="hero-desc">
              Explore our curated selection of top sneakers from iconic brands like Nike, Adidas, Puma, New Balance, and Converse. Original quality, ultimate comfort, and unmatched street style.
            </p>
            
            {/* CTA actions */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4" id="hero-cta">
              <Link to="/products">
                <Button variant="secondary" className="w-full sm:w-auto h-12 text-sm px-8 rounded-xl font-bold uppercase tracking-wider flex items-center justify-center gap-2 bg-orange-500 text-black hover:bg-white hover:text-black transition-colors border-none">
                  Shop Best Sellers <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Link to="/about">
                <Button variant="outline" className="w-full sm:w-auto h-12 text-sm px-8 rounded-xl font-bold uppercase tracking-wider bg-transparent border-white/20 text-white hover:bg-white/10 hover:border-white">
                  Learn Our Story
                </Button>
              </Link>
            </div>
          </div>

          {/* Background gradient blur */}
          <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-gradient-to-br from-transparent to-orange-500/25 blur-3xl pointer-events-none"></div>
        </motion.div>

        {/* HERO FEATURED SNEAKER BENTO CARD (White theme with brand details, spans 5 cols) */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="lg:col-span-5 bg-white rounded-3xl p-8 border border-slate-200 shadow-sm flex flex-col justify-between relative overflow-hidden min-h-[460px]"
          id="hero-bento-right"
        >
          {/* Subtle logo vector outline */}
          <div className="absolute -bottom-10 -right-5 text-slate-100 font-black italic text-[120px] select-none pointer-events-none uppercase">
            KICKS
          </div>

          <div className="flex justify-between items-start z-10">
            <div>
              <span className="text-orange-600 text-xs font-black uppercase tracking-wider">Hot Pick</span>
              <h3 className="text-2xl font-extrabold text-slate-900 mt-0.5">Nike Air Max Pulse</h3>
              <p className="text-slate-500 text-xs mt-1">Light Bone / Summit White</p>
            </div>
            <span className="text-2xl font-black text-slate-900">$150.00</span>
          </div>

          {/* Shoe Image in a nice container */}
          <div className="my-6 flex items-center justify-center relative z-10 h-48 bg-slate-50/50 rounded-2xl border border-slate-100 overflow-hidden group">
            <div className="w-32 h-32 bg-orange-400 rounded-full blur-3xl absolute opacity-10 group-hover:opacity-20 transition-opacity"></div>
            <img
              src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80"
              alt="Featured Nike Sneaker"
              className="h-40 w-auto object-contain transform -rotate-6 group-hover:rotate-0 group-hover:scale-105 transition-all duration-500"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="flex justify-between items-center z-10 pt-2">
            <div className="flex items-center gap-6">
              <div>
                <p className="text-lg font-black text-slate-900">10k+</p>
                <p className="text-[10px] text-slate-400 font-bold uppercase">Buyers</p>
              </div>
              <div className="h-8 w-px bg-slate-200"></div>
              <div>
                <p className="text-lg font-black text-slate-900">4.9</p>
                <p className="text-[10px] text-slate-400 font-bold uppercase">Rating</p>
              </div>
            </div>
            
            <Link to="/product/1" className="text-sm font-bold text-slate-900 hover:text-orange-600 flex items-center gap-1 group">
              View Details 
              <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </motion.div>

      </div>
    </div>
  );
}
