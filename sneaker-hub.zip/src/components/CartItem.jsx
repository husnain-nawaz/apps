import React from 'react';
import { Trash2, Plus, Minus } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { motion } from 'motion/react';

export default function CartItem({ item }) {
  const { updateCartQuantity, removeFromCart } = useShop();

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="flex flex-col sm:flex-row items-center gap-4 p-4 bg-white border border-slate-100 rounded-2xl shadow-sm"
      id={`cart-item-${item.id}`}
    >
      {/* PRODUCT IMAGE */}
      <div className="w-20 h-20 rounded-xl bg-slate-50 flex items-center justify-center p-2 shrink-0">
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-contain"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* DETAILS */}
      <div className="flex-grow text-center sm:text-left space-y-1">
        <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-100">
          {item.brand}
        </span>
        <h4 className="font-extrabold text-slate-800 text-sm mt-1">{item.name}</h4>
        <p className="text-xs text-slate-500 font-medium">Category: {item.category}</p>
      </div>

      {/* CONTROLS (QUANTITY, PRICE, ACTIONS) */}
      <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto mt-2 sm:mt-0 pt-3 sm:pt-0 border-t sm:border-t-0 border-slate-100">
        
        {/* Quantity selector buttons */}
        <div className="flex items-center border border-slate-200 rounded-xl bg-slate-50 overflow-hidden">
          <button
            onClick={() => updateCartQuantity(item.id, 'decrease')}
            className="p-2 hover:bg-slate-150 text-slate-500 transition-colors cursor-pointer"
            aria-label="Decrease quantity"
            id={`qty-dec-${item.id}`}
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <span className="px-3 text-sm font-bold text-slate-800 select-none">
            {item.quantity}
          </span>
          <button
            onClick={() => updateCartQuantity(item.id, 'increase')}
            className="p-2 hover:bg-slate-150 text-slate-500 transition-colors cursor-pointer"
            aria-label="Increase quantity"
            id={`qty-inc-${item.id}`}
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Total Price */}
        <div className="text-right min-w-[70px]">
          <span className="text-xs text-slate-400 font-medium block sm:hidden">Subtotal</span>
          <p className="text-sm font-black text-slate-950">${item.price * item.quantity}</p>
          <p className="text-[10px] text-slate-400 font-medium">(${item.price} each)</p>
        </div>

        {/* Remove Button */}
        <button
          onClick={() => removeFromCart(item.id)}
          className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-all cursor-pointer"
          aria-label="Remove item"
          id={`cart-item-remove-${item.id}`}
        >
          <Trash2 className="w-4 h-4" />
        </button>

      </div>
    </motion.div>
  );
}
