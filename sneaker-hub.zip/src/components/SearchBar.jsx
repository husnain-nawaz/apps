import React from 'react';
import { Search, X } from 'lucide-react';

// SearchBar component to handle text filtering.
// Props:
// - value: current search string
// - onChange: function callback to handle input changes
// - onClear: function callback to clear search input
export default function SearchBar({ value, onChange, onClear }) {
  return (
    <div className="relative w-full" id="search-bar-wrapper">
      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
        <Search className="w-5 h-5" />
      </div>
      
      <input
        type="text"
        placeholder="Search sneakers by name or description..."
        value={value}
        onChange={onChange}
        className="w-full pl-11 pr-10 py-3 rounded-2xl bg-white border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 text-sm font-medium transition-all text-slate-800 shadow-sm"
        id="search-input"
      />

      {value && (
        <button
          onClick={onClear}
          className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
          id="search-clear-btn"
          aria-label="Clear Search"
        >
          <X className="w-4 h-4 bg-slate-200/50 hover:bg-slate-200 rounded-full p-0.5" />
        </button>
      )}
    </div>
  );
}
