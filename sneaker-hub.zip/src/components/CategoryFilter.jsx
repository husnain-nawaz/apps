import React from 'react';

// Category filter pills
// Props:
// - selectedCategory: active category string
// - onSelectCategory: callback on click
export default function CategoryFilter({ selectedCategory, onSelectCategory }) {
  const categories = ['All', 'Running', 'Casual', 'Sports'];

  return (
    <div className="space-y-2" id="category-filter-container">
      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Filter by Category</h4>
      <div className="flex flex-wrap gap-2" id="category-filter-pills">
        {categories.map((category) => {
          const isActive = selectedCategory === category;
          return (
            <button
              key={category}
              onClick={() => onSelectCategory(category)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all duration-200 cursor-pointer border ${
                isActive
                  ? 'bg-black border-black text-white shadow-sm'
                  : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50'
              }`}
              id={`category-pill-${category.toLowerCase().replace(/\s+/g, '-')}`}
            >
              {category}
            </button>
          );
        })}
      </div>
    </div>
  );
}
