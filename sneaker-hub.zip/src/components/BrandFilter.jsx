import React from 'react';

// Brand filter pills
// Props:
// - selectedBrand: active brand string
// - onSelectBrand: callback on click
export default function BrandFilter({ selectedBrand, onSelectBrand }) {
  const brands = ['All', 'Nike', 'Adidas', 'Puma', 'New Balance', 'Converse'];

  return (
    <div className="space-y-2" id="brand-filter-container">
      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Filter by Brand</h4>
      <div className="flex flex-wrap gap-2" id="brand-filter-pills">
        {brands.map((brand) => {
          const isActive = selectedBrand === brand;
          return (
            <button
              key={brand}
              onClick={() => onSelectBrand(brand)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all duration-200 cursor-pointer border ${
                isActive
                  ? 'bg-black border-black text-white shadow-sm'
                  : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50'
              }`}
              id={`brand-pill-${brand.toLowerCase().replace(/\s+/g, '-')}`}
            >
              {brand}
            </button>
          );
        })}
      </div>
    </div>
  );
}
