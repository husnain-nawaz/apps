import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, Instagram, Facebook, Twitter } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-black text-slate-300 border-t border-slate-900" id="main-footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-12" id="footer-links-grid">
          
          {/* COLUMN 1: STORE DESCRIPTION */}
          <div className="space-y-4" id="footer-col-about">
            <Link to="/" className="flex items-center gap-2 group">
              <span className="bg-white text-slate-900 p-2 rounded-xl text-md font-black italic">
                SH
              </span>
              <span className="font-extrabold text-lg tracking-tight text-white uppercase">
                SNEAKER <span className="text-orange-500">HUB</span>
              </span>
            </Link>
            <p className="text-sm text-slate-400 leading-relaxed">
              Sneaker Hub is your ultimate destination for premium sneakers. We source original shoes from the world's leading brands to elevate your performance and lifestyle.
            </p>
            <div className="flex gap-4 pt-2">
              <a href="#" className="p-2 bg-slate-900 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="p-2 bg-slate-900 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="p-2 bg-slate-900 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors">
                <Twitter className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* COLUMN 2: QUICK NAVIGATION */}
          <div className="space-y-4" id="footer-col-nav">
            <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Quick Links</h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/" className="text-slate-400 hover:text-white transition-colors">Home Dashboard</Link>
              </li>
              <li>
                <Link to="/products" className="text-slate-400 hover:text-white transition-colors">Shop All Products</Link>
              </li>
              <li>
                <Link to="/about" className="text-slate-400 hover:text-white transition-colors">Our Story (About)</Link>
              </li>
              <li>
                <Link to="/contact" className="text-slate-400 hover:text-white transition-colors">Contact Support</Link>
              </li>
              <li>
                <Link to="/admin" className="text-slate-400 hover:text-white transition-colors">Admin Portal</Link>
              </li>
            </ul>
          </div>

          {/* COLUMN 3: POPULAR BRANDS */}
          <div className="space-y-4" id="footer-col-brands">
            <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Brands We Carry</h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/products?brand=Nike" className="text-slate-400 hover:text-white transition-colors">Nike Sportswear</Link>
              </li>
              <li>
                <Link to="/products?brand=Adidas" className="text-slate-400 hover:text-white transition-colors">Adidas Originals</Link>
              </li>
              <li>
                <Link to="/products?brand=Puma" className="text-slate-400 hover:text-white transition-colors">Puma Classic</Link>
              </li>
              <li>
                <Link to="/products?brand=New Balance" className="text-slate-400 hover:text-white transition-colors">New Balance Heritage</Link>
              </li>
              <li>
                <Link to="/products?brand=Converse" className="text-slate-400 hover:text-white transition-colors">Converse Chucks</Link>
              </li>
            </ul>
          </div>

          {/* COLUMN 4: STORE CONTACTS */}
          <div className="space-y-4" id="footer-col-contact">
            <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Get in Touch</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-5 h-5 text-orange-500 shrink-0 mt-0.5" />
                <span className="text-slate-400">123 Sneaker Boulevard, Street Fashion District, New York, NY 10001</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-orange-500 shrink-0" />
                <span className="text-slate-400">+1 (555) SNEAKER</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-orange-500 shrink-0" />
                <span className="text-slate-400">hello@sneakerhub.com</span>
              </li>
            </ul>
          </div>

        </div>

        {/* COPYRIGHT & TERMS */}
        <div className="mt-12 pt-8 border-t border-slate-800 text-center flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-500" id="footer-bottom-bar">
          <p>© {currentYear} Sneaker Hub Inc. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-slate-300">Privacy Policy</a>
            <a href="#" className="hover:text-slate-300">Terms of Service</a>
            <a href="#" className="hover:text-slate-300">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
