import React from 'react';
import { motion } from 'motion/react';

// Reusable Button component that standardizes branding styling across the app.
// Props:
// - children: content of the button
// - onClick: click event handler
// - type: 'button' | 'submit' | 'reset'
// - variant: 'primary' | 'secondary' | 'danger' | 'outline' | 'ghost'
// - className: extra custom classes
// - disabled: boolean
export default function Button({
  children,
  onClick,
  type = 'button',
  variant = 'primary',
  className = '',
  disabled = false,
  ...props
}) {
  // Define variant styles using standard Tailwind classes
  const baseStyle = "px-5 py-2.5 rounded-xl font-semibold text-sm transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed select-none";
  
  const variantStyles = {
    primary: "bg-black text-white hover:bg-orange-600 hover:text-white shadow-sm active:bg-slate-950",
    secondary: "bg-orange-600 text-white hover:bg-orange-500 shadow-sm active:bg-orange-700",
    outline: "border border-slate-200 text-slate-700 bg-white hover:bg-slate-50 hover:border-slate-300",
    danger: "bg-rose-600 text-white hover:bg-rose-500 shadow-sm active:bg-rose-700",
    ghost: "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
  };

  const selectedStyle = variantStyles[variant] || variantStyles.primary;

  return (
    <motion.button
      type={type}
      onClick={onClick}
      disabled={disabled}
      whileHover={{ scale: disabled ? 1 : 1.02 }}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      className={`${baseStyle} ${selectedStyle} ${className}`}
      id={`btn-${variant}`}
      {...props}
    >
      {children}
    </motion.button>
  );
}
