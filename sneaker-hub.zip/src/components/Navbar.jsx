import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { ShoppingCart, Menu, X, Hammer } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { motion, AnimatePresence } from 'motion/react';

export default function Navbar() {
  const { cartCount } = useShop();
  const [isOpen, setIsOpen] = useState(false);

  // Styling helpers for router Link active states
  const activeClass = "text-orange-600 font-bold border-b-2 border-orange-600 pb-1 text-sm";
  const inactiveClass = "text-slate-600 hover:text-black font-medium pb-1 text-sm transition-all";

  const toggleMenu = () => setIsOpen(!isOpen);

  const links = [
    { path: '/', label: 'Home' },
    { path: '/products', label: 'Shop' },
    { path: '/about', label: 'About Us' },
    { path: '/contact', label: 'Contact' },
    { path: '/admin', label: 'Admin Dashboard', icon: Hammer }
  ];

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100" id="main-navbar">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          
          {/* BRAND LOGO */}
          <Link to="/" className="flex items-center gap-2 group" id="navbar-logo">
            <span className="bg-black text-white p-2 px-3 rounded-xl text-lg font-black italic tracking-wider transition-transform group-hover:scale-105">
              SH
            </span>
            <span className="font-extrabold text-xl tracking-tight text-slate-900 group-hover:text-black uppercase">
              SNEAKER <span className="text-orange-500">HUB</span>
            </span>
          </Link>

          {/* DESKTOP NAVIGATION */}
          <div className="hidden md:flex space-x-8 items-center" id="navbar-desktop-links">
            {links.map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                className={({ isActive }) => (isActive ? activeClass : inactiveClass)}
              >
                <span className="flex items-center gap-1.5">
                  {link.icon && <link.icon className="w-4 h-4" />}
                  {link.label}
                </span>
              </NavLink>
            ))}
          </div>

          {/* ACTION BUTTONS (CART & MOBILE TOGGLE) */}
          <div className="flex items-center gap-4" id="navbar-actions">
            {/* CART ICON WITH DYNAMIC BADGE */}
            <Link to="/cart" className="relative p-2.5 hover:bg-slate-100 rounded-xl transition-all group" id="cart-button">
              <ShoppingCart className="w-6 h-6 text-slate-700 group-hover:text-orange-500 transition-colors" />
              {cartCount > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute top-1 right-1 bg-orange-600 text-white text-[10px] font-extrabold w-5 h-5 flex items-center justify-center rounded-full border-2 border-white"
                  id="cart-badge"
                >
                  {cartCount}
                </motion.span>
              )}
            </Link>

            {/* MOBILE TOGGLE ICON */}
            <button
              onClick={toggleMenu}
              className="p-2 md:hidden hover:bg-slate-50 rounded-xl transition-all text-slate-700 cursor-pointer"
              aria-label="Toggle Menu"
              id="mobile-menu-toggle"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* MOBILE SCREEN NAVIGATION DRAWER */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-slate-100 bg-white"
            id="navbar-mobile-menu"
          >
            <div className="px-4 pt-2 pb-6 space-y-3">
              {links.map((link) => (
                <NavLink
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={({ isActive }) =>
                    `flex items-center gap-2 p-3 rounded-xl transition-all ${
                      isActive
                        ? 'bg-orange-50 text-orange-600 font-bold'
                        : 'text-slate-600 hover:bg-slate-50 font-medium'
                    }`
                  }
                >
                  {link.icon && <link.icon className="w-5 h-5" />}
                  {link.label}
                </NavLink>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
