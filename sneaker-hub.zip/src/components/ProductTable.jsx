import React, { useState } from 'react';
import { Edit2, Trash2, Search, PlusCircle } from 'lucide-react';
import Button from './Button';

// ProductTable component for listing, searching, and managing products in the Admin panel.
// Props:
// - products: array of products
// - onEditProduct: callback function to trigger edit form/modal
// - onDeleteProduct: callback function to delete the product
// - onAddNewTrigger: callback function to show creation form
export default function ProductTable({
  products,
  onEditProduct,
  onDeleteProduct,
  onAddNewTrigger
}) {
  const [searchTerm, setSearchTerm] = useState('');

  // Local filter for the table list
  const filteredProducts = products.filter((prod) =>
    prod.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    prod.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
    prod.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden" id="admin-product-table">
      
      {/* Search & Actions Bar */}
      <div className="p-6 border-b border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-4 bg-slate-50/50">
        
        {/* Table Specific Search Input */}
        <div className="relative w-full sm:max-w-xs">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 pointer-events-none">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            placeholder="Search inventory..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-white border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500/15 focus:border-orange-500 font-medium"
            id="table-search-input"
          />
        </div>

        {/* Action Button */}
        <Button
          onClick={onAddNewTrigger}
          variant="secondary"
          className="w-full sm:w-auto h-10 text-xs px-4 rounded-xl font-bold flex items-center justify-center gap-1.5"
          id="btn-add-new-inventory"
        >
          <PlusCircle className="w-4 h-4" />
          Add New Shoe
        </Button>
      </div>

      {/* TABLE BODY (RESPONSIVE WRAPPER) */}
      <div className="overflow-x-auto">
        {filteredProducts.length === 0 ? (
          <div className="p-12 text-center text-slate-400 font-medium" id="table-empty-state">
            No items match your search.
          </div>
        ) : (
          <table className="min-w-full divide-y divide-slate-200 text-left text-sm" id="shoes-inventory-table">
            <thead className="bg-slate-50">
              <tr>
                <th scope="col" className="px-6 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px] border-b border-slate-200">Product Details</th>
                <th scope="col" className="px-6 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px] border-b border-slate-200">Brand</th>
                <th scope="col" className="px-6 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px] border-b border-slate-200">Category</th>
                <th scope="col" className="px-6 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px] border-b border-slate-200">Price</th>
                <th scope="col" className="px-6 py-4 font-bold text-slate-500 uppercase tracking-wider text-[11px] text-right border-b border-slate-200">Actions</th>
              </tr>
            </thead>
            
            <tbody className="divide-y divide-slate-200 bg-white">
              {filteredProducts.map((product) => (
                <tr key={product.id} className="hover:bg-slate-50/50 transition-colors" id={`table-row-${product.id}`}>
                  
                  {/* Name and Image column */}
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-lg bg-slate-50 p-1 flex items-center justify-center shrink-0 border border-slate-200">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-full h-full object-contain"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div>
                        <div className="font-extrabold text-slate-900 text-xs sm:text-sm line-clamp-1">
                          {product.name}
                        </div>
                        <div className="text-[10px] text-slate-400 font-medium">ID: #{product.id}</div>
                      </div>
                    </div>
                  </td>

                  {/* Brand column */}
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-100 text-slate-700">
                      {product.brand}
                    </span>
                  </td>

                  {/* Category column */}
                  <td className="px-6 py-4 whitespace-nowrap text-slate-500 font-medium text-xs">
                    {product.category}
                  </td>

                  {/* Price column */}
                  <td className="px-6 py-4 whitespace-nowrap font-black text-slate-900 text-xs sm:text-sm">
                    ${product.price}
                  </td>

                  {/* Actions column */}
                  <td className="px-6 py-4 whitespace-nowrap text-right text-xs">
                    <div className="flex justify-end gap-2">
                      {/* EDIT */}
                      <button
                        onClick={() => onEditProduct(product)}
                        className="p-2 rounded-lg text-slate-500 hover:text-orange-600 hover:bg-orange-50 transition-all cursor-pointer"
                        title="Edit Shoe"
                        id={`edit-btn-${product.id}`}
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>

                      {/* DELETE */}
                      <button
                        onClick={() => {
                          if (window.confirm(`Are you sure you want to delete ${product.name}?`)) {
                            onDeleteProduct(product.id);
                          }
                        }}
                        className="p-2 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-all cursor-pointer"
                        title="Delete Shoe"
                        id={`delete-btn-${product.id}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>

                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

    </div>
  );
}
