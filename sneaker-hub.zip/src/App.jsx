import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ShopProvider } from './context/ShopContext';
import MainLayout from './layouts/MainLayout';

// PAGE IMPORTS
import Home from './pages/Home';
import Products from './pages/Products';
import ProductDetails from './pages/ProductDetails';
import Cart from './pages/Cart';
import About from './pages/About';
import Contact from './pages/Contact';
import AdminDashboard from './pages/AdminDashboard';

// Main App container setting up Routing & Global State
export default function App() {
  return (
    <ShopProvider>
      <BrowserRouter>
        <MainLayout>
          <Routes>
            {/* Storefront Pages */}
            <Route path="/" element={<Home />} />
            <Route path="/products" element={<Products />} />
            <Route path="/product/:id" element={<ProductDetails />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            
            {/* Admin Management Panel */}
            <Route path="/admin" element={<AdminDashboard />} />

            {/* Catch-all 404 Fallback routing */}
            <Route
              path="*"
              element={
                <div className="text-center py-24 space-y-4" id="global-404-fallback">
                  <h2 className="text-3xl font-black text-slate-800">Page Not Found</h2>
                  <p className="text-slate-500 text-sm">The route you are trying to visit does not exist.</p>
                  <a href="/" className="inline-block mt-4 text-indigo-600 hover:underline font-bold text-sm">
                    Return to Homepage
                  </a>
                </div>
              }
            />
          </Routes>
        </MainLayout>
      </BrowserRouter>
    </ShopProvider>
  );
}
