import React, { createContext, useState, useEffect, useContext } from 'react';
import axios from 'axios';

// Create the ShopContext so other components can subscribe to its state
export const ShopContext = createContext();

// Custom hook to make using the shop context easier in components
export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};

export const ShopProvider = ({ children }) => {
  // 1. STATE FOR PRODUCTS
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // 2. STATE FOR CART - Initialize from LocalStorage if it exists, otherwise empty array
  const [cart, setCart] = useState(() => {
    const savedCart = localStorage.getItem('sneaker_hub_cart');
    return savedCart ? JSON.parse(savedCart) : [];
  });

  // 3. FETCH PRODUCTS ON MOUNT
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        
        // Check if we already have products in LocalStorage (to preserve Admin CRUD changes)
        const savedProducts = localStorage.getItem('sneaker_hub_products');
        
        if (savedProducts) {
          // If we have saved products (including custom added/edited/deleted ones), use them
          setProducts(JSON.parse(savedProducts));
        } else {
          // Otherwise, fetch from our simulated REST API endpoint (/products.json) using Axios
          const response = await axios.get('/products.json');
          setProducts(response.data);
          // Initialize LocalStorage with fetched products
          localStorage.setItem('sneaker_hub_products', JSON.stringify(response.data));
        }
        setLoading(false);
      } catch (err) {
        console.error('Error fetching product data:', err);
        setError('Failed to load products. Please try again.');
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  // 4. PERSIST CART TO LOCAL STORAGE WHEN IT CHANGES
  useEffect(() => {
    localStorage.setItem('sneaker_hub_cart', JSON.stringify(cart));
  }, [cart]);

  // 5. HELPER FUNCTION TO PERSIST PRODUCTS AFTER ADMIN OPERATIONS
  const saveProductsToStorage = (updatedProducts) => {
    setProducts(updatedProducts);
    localStorage.setItem('sneaker_hub_products', JSON.stringify(updatedProducts));
  };

  // --- CART OPERATIONS ---

  // Add item to cart
  const addToCart = (product, quantity = 1) => {
    setCart((prevCart) => {
      // Check if product is already in the cart
      const existingItem = prevCart.find((item) => item.id === product.id);
      
      if (existingItem) {
        // If it exists, update the quantity
        return prevCart.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      } else {
        // If it is new, add it to the cart
        return [...prevCart, { ...product, quantity }];
      }
    });
  };

  // Remove item from cart
  const removeFromCart = (productId) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== productId));
  };

  // Update item quantity (increase or decrease)
  const updateCartQuantity = (productId, action) => {
    setCart((prevCart) =>
      prevCart
        .map((item) => {
          if (item.id === productId) {
            const newQty = action === 'increase' ? item.quantity + 1 : item.quantity - 1;
            return { ...item, quantity: newQty };
          }
          return item;
        })
        // Filter out items whose quantity drops to 0 or below
        .filter((item) => item.quantity > 0)
    );
  };

  // Clear entire cart
  const clearCart = () => {
    setCart([]);
  };

  // Derived values for cart totals
  const cartTotal = cart.reduce((total, item) => total + item.price * item.quantity, 0);
  const cartCount = cart.reduce((count, item) => count + item.quantity, 0);


  // --- ADMIN SIMULATED CRUD OPERATIONS ---

  // Create Product (Add)
  const addProduct = (newProduct) => {
    const productWithId = {
      ...newProduct,
      id: products.length > 0 ? Math.max(...products.map(p => p.id)) + 1 : 1,
      rating: parseFloat(newProduct.rating || 4.5),
      reviews: parseInt(newProduct.reviews || 0, 10),
      price: parseFloat(newProduct.price)
    };
    const updated = [productWithId, ...products];
    saveProductsToStorage(updated);
  };

  // Update Product (Edit)
  const updateProduct = (id, updatedFields) => {
    const updated = products.map((prod) =>
      prod.id === id ? { ...prod, ...updatedFields, price: parseFloat(updatedFields.price) } : prod
    );
    saveProductsToStorage(updated);

    // Also update in cart if the item is present
    setCart((prevCart) =>
      prevCart.map((item) =>
        item.id === id ? { ...item, ...updatedFields, price: parseFloat(updatedFields.price) } : item
      )
    );
  };

  // Delete Product
  const deleteProduct = (id) => {
    const updated = products.filter((prod) => prod.id !== id);
    saveProductsToStorage(updated);

    // Remove from cart if deleted from store
    removeFromCart(id);
  };


  // Provide all states and functions to the children components
  return (
    <ShopContext.Provider
      value={{
        products,
        loading,
        error,
        cart,
        cartTotal,
        cartCount,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        addProduct,
        updateProduct,
        deleteProduct
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};
